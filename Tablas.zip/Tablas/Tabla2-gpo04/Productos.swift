//
//  Productos.swift
//  Tabla2-gpo04
//
//  Created by iMac on 05/04/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import Foundation

struct Producto{
    var nombre: String
    var precio: Double
    var desc: String
    var imagenp: String
}
let donuts = Producto(nombre:"dona",precio:15.0,desc:"pan redondo y delisioso", imagenp: "donuts")
let brownies = Producto(nombre: "Brownies", precio: 20.00, desc: "Pan de chocolate", imagenp: "brownies")
let butter = Producto(nombre: "Butter", precio: 13.00, desc:"Grasa Vegetal", imagenp: "butter")
let cheese = Producto(nombre: "Cheese", precio: 15.00, desc: "Producto de origen animal, derivado de la leche", imagenp: "cheese")
